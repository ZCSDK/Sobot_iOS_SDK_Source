//
//  ViewController.m
//  ZCKitDemo
//
//  Created by lizhihui on 2018/3/26.
//  Copyright © 2018年 sobot.com. All rights reserved.
//

#import "ViewController.h"
#import <SobotKit/SobotKit.h>
#import <SobotKit/ZCUIChatController.h>
//#import <SobotKit/ZCTopView.h>

#import "WebController.h"


typedef void(^PassBlock)(void);

@interface ViewController () <ZCChatControllerDelegate>

@property (nonatomic,assign) BOOL isOpenSDK;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.navigationController.navigationBarHidden = YES;
    self.title = @"title";
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (!_isOpenSDK) {
//        [self.navigationController setNavigationBarHidden:NO animated:YES];
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//     [self.navigationController setNavigationBarHidden:YES animated:NO];


}

- (IBAction)btnClick:(id)sender {
//    [self clickBtn];
//    TowViewController * tow = [[TowViewController alloc]init];
//    [self.navigationController pushViewController:tow animated:YES];
    [self clickBtn];
}


- (void)clickBtn
{
//    self.navigationController.navigationBarHidden = YES;
    ZCKitInfo * info = [[ZCKitInfo alloc] init];
//    info.leftChatColor = [UIColor whiteColor];
    info.customBannerColor = [UIColor redColor];
    ZCLibInitInfo * libInfo = [[ZCLibInitInfo alloc] init];
    libInfo.appKey = @"1ff3e4ff91314f5ca308e19570ba24bb";
//    libInfo.userId = @"34444";
    
//    libInfo.customTitle = @"客服";
    
    [ZCLibClient getZCLibClient].libInitInfo = libInfo;
    // 智齿SDK初始化启动事例
    [ZCSobot startZCChatVC:info with:self target:nil pageBlock:^(ZCChatController *object, ZCPageBlockType type) {
        if (type == ZCPageBlockLoadFinish) {
//            _isOpenSDK = YES;
//            object.chatView.moreButton.hidden = YES;
//            [object.chatView.backButton setImage:[UIImage imageNamed:@"ouyeBack"] forState:UIControlStateNormal];
//            [object.chatView.backButton setTitle:@"" forState:UIControlStateNormal];
        }
        if (type == ZCPageBlockGoBack) {
//            _isOpenSDK = NO;
        }
        
    } messageLinkClick:nil];
    
    
  

    
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
//    if (!_isOpenSDK) {
//        [self.navigationController setNavigationBarHidden:NO animated:YES];
//    }
    
}

-(void)openLeaveMsgClick:(NSString*)tipMsg
{
    NSLog(@"跳转到自定义留言页面");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
