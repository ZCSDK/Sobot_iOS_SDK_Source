//
//  ViewController.h
//  ZCKitDemo
//
//  Created by lizhihui on 2018/3/26.
//  Copyright © 2018年 sobot.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *tf;


@end

